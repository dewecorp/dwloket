<?php
include_once('../header.php');
include_once('../config/config.php');
$id = @$_GET['id'];
$sql = $koneksi->query("SELECT * FROM transaksi WHERE id_transaksi='$id'");
$data = $sql->fetch_assoc();
$status = $data['status'];
$tgl = $data['tgl'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Edit Transaksi</title>
    </head>
    <body>
        <div class="page-breadcrumb">
            <div class="row">
                <div class="col-7 align-self-center">
                    <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Transaksi</h4>
                    <div class="d-flex align-items-center">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb m-0 p-0">
                                <li class="breadcrumb-item"><a href="<?=base_url()?>" class="text-muted">Home</a></li>
                                <li class="breadcrumb-item text-muted active" aria-current="page">Edit Transaksi</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Edit Transaksi</h4>
                            <div class="float-right">
                                <a href="<?=base_url('transaksi')?>" class="btn btn-warning btn-sm btn-rounded"><i
                                    class="fa fa-arrow-right"></i>
                                Kembali</a>
                            </div><br><br>
                            <div class="row">
                                <div class="col-lg-6">
                                    <form action="#" method="POST">
                                        <div class="form-group">
                                            <label for="tgl" class="form-label">Tanggal Transaksi</label>
                                            <input type="hidden" name="id" value="<?=$data['id_transaksi']?>">
                                            <input type="date" name="tgl" value="<?=$data['tgl'];?>" class="form-control"
                                            value="<?=$data['tgl'];?>">
                                        </div>
                                        <div>
                                            <label for="idpel"> ID Pelanggan</label>
                                        </div>
                                        <div class="form-group input-group">
                                            <input type="hidden" name="id_pelanggan" id="id_pelanggan">
                                            <input type="text" name="idpel" id="idpel" class="form-control"
                                            value="<?=$data['idpel'];?>" readonly>
                                            <span class="input-group-btn">
                                                <button type="button" class="btn btn-info" data-target="#modalItem"
                                                data-toggle="modal"><i class="fa fa-search"></i>
                                                </button>
                                            </span>
                                        </div>
                                        <div class="form-group">
                                            <label for="nama" class="form-label">Nama Pelanggan</label>
                                            <input type="text" name="nama" id="nama" placeholder="Nama Pelanggan"
                                            class="form-control" value="<?=$data['nama'];?>" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label for="ket" class="form-label">Keterangan</label>
                                            <input type="text" name="ket" class="form-control" placeholder="Isi Keterangan Transaksi" value="<?=$data['ket'];?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="jenis" class="form-label">Jenis Pembayaran</label>
                                            <select class="form-control" name="jenis" id="jenis">
                                                <option value="">Jenis Pembayaran</option>
                                                <?php
                                                $sql = $koneksi->query("SELECT * FROM tb_jenisbayar ORDER BY jenis_bayar ASC");
                                                while ($tampil = $sql->fetch_assoc()) {
                                                echo "<option value='$tampil[id_bayar]'";  if($data['id_bayar'] == $tampil['id_bayar']) {echo "selected";}
                                                echo ">$tampil[jenis_bayar]</option>";
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="harga" class="form-label">Harga</label>
                                            <input type="number" name="harga" class="form-control" value="<?=$data['harga'];?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="status" class="form-label">Status</label>
                                            <select class="form-control" name="status" id="status">
                                                <option value="">Status</option>
                                                <option value="Lunas" <?php if($status == 'Lunas') {echo "selected";}?>>Lunas
                                                </option>
                                                <option value="Belum" <?php if($status == 'Belum') {echo "selected";}?>>Belum
                                                Bayar</option>
                                            </select>
                                        </div>
                                        <div class="float-right">
                                            <input type="submit" name="edit" class="btn btn-success btn-sm btn-rounded"
                                            value="Simpan">
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                if(@$_POST['edit']) {
                $id     = @$_POST['id'];
                $tgl    = @$_POST['tgl'];
                $idpel  = @$_POST['idpel'];
                $nama   = @$_POST['nama'];
                $jenis  = @$_POST['jenis'];
                $harga  = @$_POST['harga'];
                $status = @$_POST['status'];
                $ket    = @$_POST['ket'];
                
                $sql = $koneksi->query("UPDATE transaksi SET tgl='$tgl', idpel='$idpel', nama='$nama', id_bayar='$jenis', harga='$harga', status='$status', ket='$ket' WHERE id_transaksi='$id'");
                if ($sql) {
                ?>
                <script>
                alert('Transaksi Berhasil Diedit');
                window.location.href = "<?=base_url('transaksi')?>";
                </script>
                <?php
                }
                }
                ?>
            </div>
        </div>
    </body>
</html>
<?php
include_once('modal_item.php');
include_once('../footer.php');
?>