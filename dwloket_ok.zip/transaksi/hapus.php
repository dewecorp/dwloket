<?php
include_once('../config/config.php');
$id = @$_GET['id'];

$koneksi->query("DELETE FROM transaksi WHERE id_transaksi='$id'");

 ?>

 <script type="text/javascript">
 alert('Transaksi Berhasil Dihapus')
 window.location.href="<?=base_url('transaksi')?>";
 </script>
