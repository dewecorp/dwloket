<?php
include_once('../header.php');
$id = @$_GET['id'];
$sql = $koneksi->query("SELECT * FROM transaksi WHERE id_transaksi ='$id'");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi</title>
</head>

<body>
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-7 align-self-center">
                <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Transaksi</h4>
                <div class="d-flex align-items-center">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb m-0 p-0">
                            <li class="breadcrumb-item"><a href="<?=base_url('home')?>" class="text-muted">Home</a></li>
                            <li class="breadcrumb-item text-muted active" aria-current="page">Transaksi</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Data Transaksi</h4>
                        <div class="float-right">
                            <a href="<?=base_url('transaksi/cari_transaksi.php')?>" class="btn btn-success btn-sm btn-rounded"><i class="fa fa-filter"></i> Filter
                            </a>
                            <a href="<?=base_url('laporan/rekap_transaksi.php')?>" target="_blank" class="btn btn-secondary btn-sm btn-rounded"><i class="fa fa-print"></i> Cetak
                            </a>
                            <a href="<?=base_url('transaksi/tambah.php')?>" class="btn btn-primary btn-sm btn-rounded"><i class="fa fa-plus"></i> Tambah
                            </a>
                            <br><br>
                        </div><br><br>
                        <div class="table-responsive">
                            <table id="zero_config" class="table table-striped table-hover table-bordered no-wrap">
                                <thead>
                                    <tr>
                                        <th style="width: 5px;">No</th>
                                        <th>Tanggal</th>
                                        <th>No. ID/PEL</th>
                                        <th>Nama Pelanggan</th>
                                        <th>Jenis Bayar</th>
                                        <th>Harga</th>
                                        <th>Status</th>
                                        <th style="width: 3px;">Keterangan</th>
                                        <th style="text-align: center;">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $no = 1;
                                        $sql = $koneksi->query("SELECT * FROM transaksi JOIN tb_jenisbayar ON transaksi.id_bayar = tb_jenisbayar.id_bayar ORDER BY tgl DESC");
                                        while($data = $sql->fetch_assoc()) {
                                        $tgl = $data['tgl'];
                                        $status = ($data['status'] == 'Lunas')? "<span class='badge badge-pill badge-success'>Lunas</span>" : "<span class='badge badge-pill badge-danger'>Belum Bayar</span>";
                                        ?>
                                    <tr>
                                        <td><?=$no++."."; ?></td>
                                        <td><?=date('d/m/Y', strtotime($tgl));?></td>
                                        <td><?=$data['idpel'];?></td>
                                        <td><?=$data['nama'];?></td>
                                        <td><?=$data['jenis_bayar'];?></td>
                                        <td>Rp. <?=number_format($data['harga'], 0, ",", ".");?></td>
                                        <td><?=$status?></td>
                                        <td><?=$data['ket'];?></td>
                                        <td align="center">
                                            <a href="detail_transaksi.php?id=<?=$data['id_transaksi'];?>" class="btn btn-info btn-sm btn-rounded" data-toggle="tooltip" data-placement="top" title="Detail Transaksi"><i class="fa fa-eye"></i>
                                            </a>
                                            <a href="edit.php?id=<?=$data['id_transaksi']; ?>" class="btn btn-warning btn-sm btn-rounded" data-toggle="tooltip" data-placement="top" title="Edit Transaksi"><i class="fa fa-edit"></i>
                                            </a>
                                            <a href="hapus.php?id=<?=$data['id_transaksi']; ?>" onclick="return confirm('Yakin Menghapus Data?')" class="btn btn-danger btn-sm btn-rounded" data-toggle="tooltip" data-placement="top" title="Hapus Transaksi"><i class="fa fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php
                                        }
                                        ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
        include_once('../footer.php');
    ?>
</body>

</html>
