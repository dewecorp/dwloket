<?php
include_once('../config/config.php');

$id = @$_GET['id'];
// $saldo_sekarang = $koneksi->query("SELECT * FROM tb_saldo WHERE id_saldo ='$id'");
if (@$_POST['simpan']) {
$tgl = @$_POST['tgl'];
$idpel = @$_POST['idpel'];
$nama = @$_POST['nama'];
$jenis = @$_POST['jenis'];
$harga = @$_POST['harga'];
$status = @$_POST['status'];
// $sisa_saldo = $saldo_sekarang - $harga;
// echo "$sisa_saldo";
$sql = $koneksi->query("INSERT INTO transaksi (tgl, idpel, nama, id_bayar, harga, status ) VALUES ('$tgl', '$idpel', '$nama', '$jenis', '$harga', '$status')");
// $sql2 = $koneksi->query("UPDATE tb_saldo SET saldo = $sisa_saldo WHERE id_saldo = '$id'");

?>
<script>
    alert('Transaksi Berhasil Ditambahkan');
    window.location.href = "<?=base_url('transaksi')?>";

</script>
<?php

} else if(@$_POST['edit']) {
	$id = @$_POST['id'];
	$tgl = @$_POST['tgl'];
	$idpel = @$_POST['idpel'];
	$nama = @$_POST['nama'];
	$jenis = @$_POST['jenis'];
	$harga = @$_POST['harga'];
	$status = @$_POST['status'];

	
	$sql = $koneksi->query("UPDATE transaksi SET tgl='$tgl', idpel='$idpel', nama='$nama', id_bayar='$jenis', harga='$harga', status='$status' WHERE id_transaksi='$id'");
	if ($sql) {
?>
<script>
    alert('Transaksi Berhasil Diedit');
    windo<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title> Title </title>
</head>

	<body>

</body>
</html>
w.location.href = "<?=base_url('transaksi')?>";

</script>
<?php
}
}
?>
