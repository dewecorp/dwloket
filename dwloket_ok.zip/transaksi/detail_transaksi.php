<?php
include_once('../header.php');
include_once('../config/config.php');
$id = @$_GET['id'];
$sql = $koneksi->query("SELECT * FROM transaksi JOIN tb_jenisbayar ON transaksi.id_bayar = tb_jenisbayar.id_bayar WHERE id_transaksi ='$id'");
$data = $sql->fetch_assoc();
$status = ($data['status'] == 'Lunas')? "Lunas" : "Belum Bayar";
$tgl = $data['tgl'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Transaksi</title>
</head>

<body>
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-7 align-self-center">
                <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Transaksi</h4>
                <div class="d-flex align-items-center">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb m-0 p-0">
                            <li class="breadcrumb-item"><a href="<?=base_url('home')?>" class="text-muted">Home</a></li>
                            <li class="breadcrumb-item text-muted active" aria-current="page">Detail Transaksi</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Detail Transaksi</h4><br>
                        <div class="col-lg-12">
                            <table class="table-responsive">
                                <tr>
                                    <td>
                                        <div class="form-group">ID Transaksi</div>
                                    </td>
                                    <td align="center" width="25%">
                                        <div class="form-group">:</div>
                                    </td>
                                    <td>
                                        <div class="form-group">
                                            <?=$data['id_transaksi']?>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="form-group">Tanggal Transaksi</div>
                                    </td>
                                    <td align="center" width="5%">
                                        <div class="form-group">:</div>
                                    </td>
                                    <td>
                                        <div class="form-group">
                                            <?=date('d/m/Y', strtotime($tgl))?>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="form-group">ID Pelanggan</div>
                                    </td>
                                    <td align="center" width="5%">
                                        <div class="form-group">:</div>
                                    </td>
                                    <td>
                                        <div class="form-group">
                                            <?=$data['idpel']; ?>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="form-group">Nama Pelanggan</div>
                                    </td>
                                    <td align="center" width="5%">
                                        <div class="form-group">:</div>
                                    </td>
                                    <td>
                                        <div class="form-group">
                                            <?=$data['nama']; ?>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="form-group">Jenis Pembayaran</div>
                                    </td>
                                    <td align="center" width="5%">
                                        <div class="form-group">:</div>
                                    </td>
                                    <td>
                                        <div class="form-group">
                                            <?=$data['jenis_bayar']; ?>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="form-group">Harga</div>
                                    </td>
                                    <td align="center" width="5%">
                                        <div class="form-group">:</div>
                                    </td>
                                    <td>
                                        <div class="form-group">
                                            Rp. <?=number_format($data['harga'], 0, ",", ".");?>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="form-group">Status</div>
                                    </td>
                                    <td align="center" width="5%">
                                        <div class="form-group">:</div>
                                    </td>
                                    <td>
                                        <div class="form-group">
                                            <?=$status?>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="form-group">Keterangan</div>
                                    </td>
                                    <td align="center" width="5%">
                                        <div class="form-group">:</div>
                                    </td>
                                    <td>
                                        <div class="form-group">
                                           <?=$data['ket']; ?>
                                        </div>
                                    </td>
                                </tr>
                            </table><br>

                            <div class="float-left">
                                <a href="../cetak_transaksi.php?&id=<?=$data['id_transaksi'];?>" target="_blank"
                                    class="btn btn-primary btn-sm btn-rounded"><i class="fa fa-print"></i> Kertas A4/F4
                                </a>
                                <a href="../cetak_kecil.php?&id=<?=$data['id_transaksi'];?>" target="_blank"
                                    class="btn btn-primary btn-sm btn-rounded"><i class="fa fa-print"></i> Kertas
                                    POS
                                </a>
                                <a href="<?=base_url('transaksi')?>" class="btn btn-warning btn-sm btn-rounded">
                                    <i class="fa fa-arrow-right"></i> Kembali
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
	include_once('../footer.php');
	?>
</body>

</html>