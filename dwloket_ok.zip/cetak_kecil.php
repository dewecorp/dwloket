<?php
include_once('config/config.php');
setlocale(LC_ALL, 'id-ID', 'id_ID');
date_default_timezone_set('Asia/Jakarta');
$id = @$_GET['id'];
$sql = $koneksi->query("SELECT * FROM transaksi JOIN tb_jenisbayar ON transaksi.id_bayar = tb_jenisbayar.id_bayar WHERE id_transaksi = '$id'");
$data = $sql->fetch_assoc();
$tgl = $data['tgl'];
$harga = $data['harga'];?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Struk Transaksi</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <link rel="icon" type="image/png" sizes="16x16" href="files/assets/images/dwloket_icon.png">
    <!-- <link href="files/dist/css/style.min.css" rel="stylesheet"> -->
</head>

<body>
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-6">
                <div class="card w-50">
                    <div class="card-body">

                        <center>
                            <p><?=date('d/m/Y H:i:s');?></p>
                            <h4 style="margin-bottom: 20px; font-size: 14px">STRUK TRANSAKSI</h4>
                        </center>

                        <div align="center" style="font-size: 14px">
                            <table>
                                <tr>
                                    <td style="width: 50%;">ID Trx</td>
                                    <td style="width: 10%;">:</td>
                                    <td style="width: 80%;"><?=$data['id_transaksi'];?></td>
                                </tr>
                                <tr>
                                    <td style="width: 30%;">Tanggal</td>
                                    <td style="width: 10%;">:</td>
                                    <td style="width: 65%;"><?=date('d/m/Y', strtotime($tgl));?></td>
                                </tr>
                                <tr>
                                    <td style="width: 30%;">ID Pel</td>
                                    <td style="width: 10%;">:</td>
                                    <td style="width: 65%;"><?=$data['idpel'];?></td>
                                </tr>
                                <tr>
                                    <td style="width: 30%; vertical-align: top;">Nama</td>
                                    <td style="width: 10%;">:</td>
                                    <td style="width: 65%;"><?=$data['nama'];?></td>
                                </tr>
                                <tr>
                                    <td style="width: 30%; vertical-align: top;">Jenis Bayar</td>
                                    <td style="width: 10%;">:</td>
                                    <td style="width: 65%;"><?=$data['jenis_bayar'];?></td>
                                </tr>
                                <tr>
                                    <td style="width: 30%;">Harga</td>
                                    <td style="width: 10%;">:</td>
                                    <td style="width: 65%;">Rp. <?=number_format($data['harga'], 0, ",", ".");?>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 30%;">Keterangan</td>
                                    <td style="width: 10%;">:</td>
                                    <td style="width: 70%;"><?=$data['ket'];?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div><br>
                            <center>
                                <h4 style="font-size: 14px">
                                    <i><?=terbilang($harga);?> Rupiah</i>
                                </h4>
                                <h3 style="font-size: 12px">Terima Kasih Atas Kepercayaan Anda</h3>
                            </center>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
<script>
    window.print();

</script>
