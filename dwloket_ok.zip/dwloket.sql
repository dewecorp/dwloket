-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 29, 2021 at 08:20 AM
-- Server version: 5.7.24
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dwloket`
--

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `no_idpel` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama`, `no_idpel`) VALUES
(2, 'NUR HUDA', '86037218053'),
(3, 'TPQ ASSALAMAH', '14311140462'),
(5, 'DIMYATI', '86030038441'),
(6, 'HISYAM AHMAD', '520020664080'),
(7, 'ADNAN JAWAHIR', '520021142578'),
(9, 'SRI BATHI', '520020784796'),
(10, 'HARTANTO', '14338468755'),
(11, 'SARKAWI', '520020509931'),
(12, 'SYARONI', '520020786612'),
(13, 'SUBIYANTO', '520021150627'),
(14, 'NGASIMAN', '520020509367'),
(15, 'DARJO/KUMATUN', '520020509213'),
(16, 'SUPARDI', '520020509495'),
(17, 'AMINUDDIN', '32013850485'),
(18, 'SITI NGATEMI', '520021307881'),
(19, 'KHOLIS S/KALIS', '520020509342'),
(20, 'KASENAN', '520020732762'),
(21, 'MUHDI/JUMANAH', '520020509375'),
(22, 'SUDARLIM', '45013589978'),
(23, 'MARKAM MARIYAM', '520020509509'),
(25, 'JUMADI', '520020509168'),
(27, 'ZAINI/NARNIT', '520020765894'),
(28, 'DARSONO', '520021070308'),
(29, 'MBAK SITI XL', '085936107927'),
(30, 'VIOLA', '083183037136'),
(31, 'MUHAMMAD NURROIN', '082137145353'),
(32, 'DEWI ANISAH', '081227999566'),
(33, 'MBAK SITI PULSA', '081325587075'),
(34, 'SALWA', '087737627807'),
(35, 'IDA ROHALIA', '082314010696'),
(38, 'NN', '86037218053'),
(39, 'PAK ALI', '45028196124'),
(40, 'PARTI/HARYANTO', '56212261889');

-- --------------------------------------------------------

--
-- Table structure for table `tb_jenisbayar`
--

CREATE TABLE `tb_jenisbayar` (
  `id_bayar` int(11) NOT NULL,
  `jenis_bayar` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_jenisbayar`
--

INSERT INTO `tb_jenisbayar` (`id_bayar`, `jenis_bayar`) VALUES
(1, 'Token PLN'),
(2, 'PLN Pasca Bayar'),
(3, 'Pulsa Telkomsel'),
(4, 'Shopee Pay'),
(5, 'Data Internet Telkomsel'),
(6, 'PDAM '),
(7, 'Data Internet 3'),
(8, 'Data Internet AXIS'),
(9, 'Data Internet Smartfren'),
(10, 'Data Internet XL'),
(11, 'Data Internet Indosat'),
(12, 'Indihome'),
(13, 'Wifi ID'),
(14, 'BRIZZI'),
(15, 'E-Mandiri'),
(16, 'Transfer Uang'),
(17, 'Pulsa XL'),
(18, 'Pulsa AXIS'),
(19, 'Pulsa Indosat'),
(20, 'Pulsa TRI'),
(21, 'Pulsa SMARTFREN'),
(22, 'Grab Ovo'),
(23, 'BPJS Tenaga Kerja'),
(24, 'BPJS Kesehatan'),
(25, 'E-Toll');

-- --------------------------------------------------------

--
-- Table structure for table `tb_saldo`
--

CREATE TABLE `tb_saldo` (
  `id_saldo` int(11) NOT NULL,
  `tgl` varchar(50) NOT NULL,
  `saldo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_saldo`
--

INSERT INTO `tb_saldo` (`id_saldo`, `tgl`, `saldo`) VALUES
(8, '2021-03-14', '300000'),
(9, '2021-03-17', '400000'),
(10, '2021-03-22', '480000'),
(11, '2021-03-30', '150000'),
(12, '2021-04-05', '150000'),
(13, '2021-04-10', '150000'),
(14, '2021-04-20', '250000'),
(15, '2021-04-23', '1000000'),
(16, '2021-05-05', '100000'),
(17, '2021-05-20', '350000'),
(18, '2021-05-23', '170000'),
(19, '2021-05-29', '130000'),
(20, '2021-05-30', '200000'),
(21, '2021-05-31', '400000'),
(22, '2021-06-17', '200000'),
(23, '2021-06-20', '400000'),
(24, '2021-06-27', '300000'),
(25, '2021-07-21', '350000'),
(26, '2021-07-26', '400000'),
(27, '2021-08-21', '300000'),
(28, '2021-08-26', '180000'),
(29, '2021-09-08', '150000'),
(30, '2021-09-18', '170000');

-- --------------------------------------------------------

--
-- Table structure for table `tb_saldo_akhir`
--

CREATE TABLE `tb_saldo_akhir` (
  `id_saldo_akhr` int(11) NOT NULL,
  `saldo_masuk` int(50) NOT NULL,
  `saldo_keluar` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `foto` varchar(50) NOT NULL,
  `level` enum('admin','user') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `username`, `password`, `nama`, `email`, `foto`, `level`) VALUES
(2, 'admin', 'admin', 'NUR HUDA', 'ibnu.hasan3@gmail.com', 'foto-1614766465.JPG', 'admin'),
(3, 'admin2', 'admin2', 'HUDA NUR', 'hudadotkom@gmail.com', 'foto-1614779727.jpg', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `tgl` date NOT NULL,
  `idpel` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `id_bayar` int(11) NOT NULL,
  `harga` varchar(100) NOT NULL,
  `status` enum('Lunas','Belum') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `tgl`, `idpel`, `nama`, `id_bayar`, `harga`, `status`) VALUES
(20, '2021-01-23', '86030038441', 'DIMYATI', 1, '105000', 'Lunas'),
(21, '2021-01-25', '0001', 'MBAK SITI', 3, '22000', 'Lunas'),
(22, '2021-01-26', '14338468755', 'HARTANTO', 1, '23000', 'Lunas'),
(23, '2021-01-25', '86037218053', 'NUR HUDA', 16, '13200', 'Belum'),
(24, '2021-01-29', '86030038441', 'DIMYATI', 1, '105000', 'Lunas'),
(25, '2021-01-30', '86037218053', 'NUR HUDA', 8, '28351', 'Belum'),
(26, '2021-01-30', '0003', 'MUHAMMAD NURROIN', 3, '22000', 'Belum'),
(27, '2021-01-30', '0003', 'MUHAMMAD NURROIN', 17, '32000', 'Belum'),
(28, '2021-02-01', '86037218053', 'NUR HUDA', 8, '30000', 'Belum'),
(29, '2021-02-01', '004', 'DEWI ANISAH', 4, '100500', 'Lunas'),
(30, '2021-02-01', '004', 'DEWI ANISAH', 4, '50500', 'Lunas'),
(31, '2021-02-02', '86037218053', 'NUR HUDA', 5, '15000', 'Belum'),
(32, '2021-02-03', '14311140462', 'TPQ ASSALAMAH', 1, '105000', 'Lunas'),
(33, '2021-02-06', '002', 'VIOLA', 8, '25000', 'Lunas'),
(34, '2021-02-07', '86037218053', 'NUR HUDA', 20, '20000', 'Belum'),
(35, '2021-02-08', '004', 'DEWI ANISAH', 3, '20000', 'Belum'),
(36, '2021-02-08', '86037218053', 'NUR HUDA', 8, '20000', 'Belum'),
(37, '2021-02-09', '085936107927', 'MBAK SITI', 10, '40000', 'Lunas'),
(38, '2021-02-13', '86037218053', 'NUR HUDA', 8, '15000', 'Belum'),
(39, '2021-02-15', '86030038441', 'DIMYATI', 1, '105000', 'Lunas'),
(40, '2021-02-17', '86037218053', 'NUR HUDA', 1, '53000', 'Belum'),
(41, '2021-02-17', '86037218053', 'NUR HUDA', 8, '20000', 'Belum'),
(42, '2021-02-19', '520020786612', 'SYARONI', 2, '63000', 'Lunas'),
(43, '2021-02-21', '14338468755', 'HARTANTO', 1, '23000', 'Lunas'),
(44, '2021-02-21', '520021150627', 'SUBIYANTO', 2, '66000', 'Lunas'),
(45, '2021-02-22', '86037218053', 'NUR HUDA', 8, '20000', 'Belum'),
(46, '2021-02-23', '081227999566', 'DEWI ANISAH', 3, '22000', 'Lunas'),
(47, '2021-03-15', '087737627807', 'SALWA', 10, '62000', 'Lunas'),
(48, '2021-03-15', '083183037136', 'VIOLA', 18, '7000', 'Lunas'),
(49, '2021-02-26', '86037218053', 'NUR HUDA', 8, '20000', 'Belum'),
(51, '2021-03-02', '86030038441', 'DIMYATI', 1, '105000', 'Lunas'),
(52, '2021-03-03', '86037218053', 'NUR HUDA', 5, '17000', 'Belum'),
(53, '2021-03-03', '86037218053', 'NUR HUDA', 18, '25000', 'Belum'),
(54, '2021-03-04', '082137145353', 'MUHAMMAD NURROIN', 3, '22000', 'Lunas'),
(55, '2021-03-04', '14311140462', 'TPQ ASSALAMAH', 1, '105000', 'Lunas'),
(56, '2021-03-04', '86037218053', 'NUR HUDA', 1, '53000', 'Belum'),
(57, '2021-03-06', '082314010696', 'IDA ROHALIA', 3, '22000', 'Lunas'),
(58, '2021-03-06', '082314010696', 'IDA ROHALIA', 20, '52000', 'Lunas'),
(59, '2021-03-06', '86037218053', 'NUR HUDA', 8, '20000', 'Belum'),
(60, '2021-03-11', '86037218053', 'NUR HUDA', 8, '20000', 'Belum'),
(61, '2021-03-15', '085936107927', 'MBAK SITI XL', 10, '40000', 'Lunas'),
(62, '2021-03-15', '083183037136', 'VIOLA', 8, '15000', 'Lunas'),
(63, '2021-03-14', '14338468755', 'HARTANTO', 1, '53000', 'Lunas'),
(64, '2021-03-15', '86037218053', 'NUR HUDA', 8, '20000', 'Belum'),
(65, '2021-03-15', '86037218053', 'NUR HUDA', 3, '15000', 'Belum'),
(67, '2021-03-17', '86037218053', 'NUR HUDA', 16, '117000', 'Lunas'),
(68, '2021-03-18', '86037218053', 'NUR HUDA', 1, '53000', 'Belum'),
(69, '2021-03-20', '86037218053', 'NUR HUDA', 8, '16000', 'Belum'),
(70, '2021-03-21', '082314010696', 'IDA ROHALIA', 3, '52000', 'Belum'),
(71, '2021-03-22', '520020732762', 'KASENAN', 2, '420000', 'Lunas'),
(72, '2021-03-22', '520021150627', 'SUBIYANTO', 2, '61000', 'Lunas'),
(73, '2021-03-25', '86037218053', 'NUR HUDA', 8, '22000', 'Belum'),
(74, '2021-03-25', '520020509213', 'DARJO/KUMATUN', 2, '20000', 'Lunas'),
(75, '2021-03-25', '86037218053', 'NUR HUDA', 3, '22000', 'Belum'),
(76, '2021-03-26', '520020786612', 'SYARONI', 2, '63000', 'Lunas'),
(77, '2021-03-27', '087737627807', 'SALWA', 10, '62000', 'Lunas'),
(78, '2021-03-28', '86037218053', 'NUR HUDA', 8, '15000', 'Belum'),
(79, '2021-03-30', '86037218053', 'NUR HUDA', 1, '53000', 'Belum'),
(80, '2021-03-30', '081227999566', 'DEWI ANISAH', 3, '22000', 'Belum'),
(81, '2021-03-31', '86030038441', 'DIMYATI', 1, '23000', 'Lunas'),
(82, '2021-04-03', '86030038441', 'DIMYATI', 1, '23000', 'Lunas'),
(83, '2021-04-05', '86030038441', 'DIMYATI', 1, '105000', 'Lunas'),
(84, '2021-04-07', '86037218053', 'NUR HUDA', 8, '16000', 'Belum'),
(85, '2021-04-07', '083183037136', 'VIOLA', 8, '15000', 'Lunas'),
(86, '2021-04-10', '082137145353', 'MUHAMMAD NURROIN', 3, '22000', 'Belum'),
(87, '2021-04-10', '085936107927', 'MBAK SITI XL', 10, '40000', 'Lunas'),
(88, '2021-04-18', '520020509509', 'MARKAM MARIYAM', 2, '8000', 'Lunas'),
(89, '2021-04-19', '520020509495', 'SUPARDI', 2, '14000', 'Lunas'),
(90, '2021-04-19', '86037218053', 'NUR HUDA', 8, '15000', 'Belum'),
(91, '2021-04-19', '520021150627', 'SUBIYANTO', 2, '57500', 'Lunas'),
(92, '2021-04-20', '520020786612', 'SYARONI', 2, '104000', 'Lunas'),
(93, '2021-04-20', '083183037136', 'VIOLA', 8, '25000', 'Lunas'),
(94, '2021-04-23', '86037218053', 'NUR HUDA', 8, '20000', 'Belum'),
(95, '2021-04-23', '520020784796', 'SRI BATHI', 2, '50500', 'Lunas'),
(96, '2021-04-23', '86037218053', 'NUR HUDA', 1, '53000', 'Belum'),
(97, '2021-04-23', '081227999566', 'DEWI ANISAH', 4, '150000', 'Lunas'),
(98, '2021-04-25', '081227999566', 'DEWI ANISAH', 4, '75000', 'Lunas'),
(99, '2021-04-25', '081227999566', 'DEWI ANISAH', 3, '30000', 'Lunas'),
(100, '2021-04-25', '520020664080', 'HISYAM AHMAD', 2, '11000', 'Lunas'),
(101, '2021-04-25', '14338468755', 'HARTANTO', 1, '23000', 'Lunas'),
(102, '2021-05-05', '86037218053', 'NUR HUDA', 8, '20000', 'Belum'),
(103, '2021-05-05', '081227999566', 'DEWI ANISAH', 4, '50000', 'Belum'),
(104, '2021-05-09', '14338468755', 'HARTANTO', 1, '53000', 'Lunas'),
(105, '2021-05-20', '520020509342', 'KHOLIS S/KALIS', 2, '28500', 'Lunas'),
(106, '2021-05-20', '520020664080', 'HISYAM AHMAD', 2, '8500', 'Lunas'),
(107, '2021-05-21', '520020786612', 'SYARONI', 2, '86000', 'Lunas'),
(108, '2021-05-22', '520020509495', 'SUPARDI', 2, '16500', 'Lunas'),
(109, '2021-05-22', '520020509509', 'MARKAM MARIYAM', 2, '10500', 'Lunas'),
(110, '2021-05-22', '45013589978', 'SUDARLIM', 1, '53000', 'Belum'),
(111, '2021-05-23', '520021150627', 'SUBIYANTO', 2, '65500', 'Lunas'),
(112, '2021-05-27', '86037218053', 'NUR HUDA', 1, '53000', 'Belum'),
(113, '2021-05-29', '520020784796', 'SRI BATHI', 2, '60000', 'Lunas'),
(114, '2021-05-29', '86030038441', 'DIMYATI', 1, '105000', 'Lunas'),
(115, '2021-05-29', '520020509168', 'JUMADI', 2, '18000', 'Lunas'),
(116, '2021-06-02', '86037218053', 'NUR HUDA', 8, '20000', 'Belum'),
(117, '2021-06-15', '86037218053', 'NUR HUDA', 8, '13000', 'Belum'),
(118, '2021-06-15', '86037218053', 'NUR HUDA', 9, '28000', 'Belum'),
(119, '2021-06-15', '86037218053', 'NUR HUDA', 1, '53000', 'Belum'),
(120, '2021-06-15', '86030038441', 'DIMYATI', 1, '105000', 'Lunas'),
(121, '2021-06-16', '14311140462', 'TPQ ASSALAMAH', 1, '105000', 'Lunas'),
(122, '2021-06-17', '14338468755', 'HARTANTO', 1, '53000', 'Lunas'),
(123, '2021-06-17', '087737627807', 'SALWA', 10, '62000', 'Lunas'),
(124, '2021-06-19', '520021150627', 'SUBIYANTO', 2, '64000', 'Lunas'),
(125, '2021-06-20', '520020509495', 'SUPARDI', 2, '15500', 'Lunas'),
(126, '2021-06-20', '520020509509', 'MARKAM MARIYAM', 2, '7500', 'Lunas'),
(127, '2021-06-20', '520020664080', 'HISYAM AHMAD', 2, '9000', 'Lunas'),
(128, '2021-06-20', '081227999566', 'DEWI ANISAH', 4, '110000', 'Lunas'),
(129, '2021-06-22', '520020509213', 'DARJO/KUMATUN', 2, '26500', 'Lunas'),
(130, '2021-06-25', '520021070308', 'DARSONO', 2, '6500', 'Lunas'),
(136, '2021-06-27', '520020509168', 'JUMADI', 2, '18500', 'Lunas'),
(140, '2021-06-29', '86037218053', 'NUR HUDA', 1, '53000', 'Belum'),
(141, '2021-06-29', '86030038441', 'DIMYATI', 1, '105000', 'Lunas'),
(142, '2021-07-01', '86037218053', 'NUR HUDA', 3, '12000', 'Belum'),
(143, '2021-07-04', '14311140462', 'TPQ ASSALAMAH', 1, '105000', 'Lunas'),
(144, '2021-07-06', '86037218053', 'NUR HUDA', 8, '20000', 'Belum'),
(145, '2021-07-15', '14338468755', 'HARTANTO', 1, '23000', 'Lunas'),
(146, '2021-07-17', '087737627807', 'SALWA', 10, '40000', 'Lunas'),
(147, '2021-07-17', '520020784796', 'SRI BATHI', 2, '56500', 'Lunas'),
(148, '2021-07-17', '86030038441', 'DIMYATI', 1, '105000', 'Lunas'),
(149, '2021-07-19', '520020509495', 'SUPARDI', 2, '16000', 'Lunas'),
(150, '2021-07-19', '520020509509', 'MARKAM MARIYAM', 2, '6000', 'Lunas'),
(151, '2021-07-19', '520020664080', 'HISYAM AHMAD', 2, '10000', 'Lunas'),
(152, '2021-07-21', '520021150627', 'SUBIYANTO', 2, '65000', 'Lunas'),
(153, '2021-07-21', '86037218053', 'NUR HUDA', 1, '53000', 'Belum'),
(154, '2021-07-22', '45013589978', 'SUDARLIM', 1, '53000', 'Lunas'),
(155, '2021-07-23', '520020509168', 'JUMADI', 2, '18500', 'Lunas'),
(156, '2021-07-25', '520021070308', 'DARSONO', 2, '8500', 'Lunas'),
(157, '2021-07-27', '087737627807', 'SALWA', 10, '60000', 'Lunas'),
(158, '2021-07-31', '083183037136', 'VIOLA', 8, '15000', 'Belum'),
(159, '2021-07-31', '86030038441', 'DIMYATI', 1, '105000', 'Lunas'),
(160, '2021-08-02', '86037218053', 'NUR HUDA', 1, '53000', 'Belum'),
(165, '2021-08-03', '081227999566', 'DEWI ANISAH', 4, '85000', 'Lunas'),
(166, '2021-08-08', '082137145353', 'MUHAMMAD NURROIN', 3, '32000', 'Lunas'),
(167, '2021-08-09', '081227999566', 'DEWI ANISAH', 3, '20000', 'Belum'),
(168, '2021-08-09', '085936107927', 'MBAK SITI XL', 10, '60000', 'Lunas'),
(169, '2021-08-13', '86037218053', 'NUR HUDA', 1, '53000', 'Belum'),
(170, '2021-08-16', '86037218053', 'NUR HUDA', 8, '20000', 'Belum'),
(171, '2021-08-16', '86030038441', 'DIMYATI', 1, '53000', 'Lunas'),
(172, '2021-08-19', '520020784796', 'SRI BATHI', 2, '48000', 'Lunas'),
(173, '2021-08-20', '86030038441', 'DIMYATI', 1, '105000', 'Lunas'),
(174, '2021-08-20', '520020786612', 'SYARONI', 2, '60500', 'Lunas'),
(175, '2021-08-21', '520020509495', 'SUPARDI', 2, '19000', 'Lunas'),
(176, '2021-08-21', '520020509509', 'MARKAM MARIYAM', 2, '11000', 'Lunas'),
(177, '2021-08-21', '520021150627', 'SUBIYANTO', 2, '68000', 'Lunas'),
(178, '2021-08-21', '082137145353', 'MUHAMMAD NURROIN', 3, '32000', 'Lunas'),
(179, '2021-08-23', '86037218053', 'NUR HUDA', 1, '53000', 'Belum'),
(180, '2021-08-26', '14338468755', 'HARTANTO', 1, '53000', 'Lunas'),
(181, '2021-08-27', '520021070308', 'DARSONO', 2, '9000', 'Lunas'),
(182, '2021-08-28', '520020509168', 'JUMADI', 2, '23000', 'Lunas'),
(183, '2021-09-02', '082137145353', 'MUHAMMAD NURROIN', 3, '27000', 'Lunas'),
(184, '2021-09-08', '86030038441', 'DIMYATI', 1, '105000', 'Lunas'),
(185, '2021-09-10', '081325587075', 'MBAK SITI PULSA', 3, '23000', 'Belum'),
(186, '2021-09-14', '082137145353', 'MUHAMMAD NURROIN', 3, '27000', 'Belum'),
(187, '2021-09-15', '86037218053', 'NUR HUDA', 1, '53000', 'Belum'),
(188, '2021-09-16', '520020784796', 'SRI BATHI', 7, '22000', 'Lunas'),
(189, '2021-09-18', '520020784796', 'SRI BATHI', 2, '40000', 'Lunas'),
(190, '2021-09-20', '520020786612', 'SYARONI', 2, '50000', 'Lunas'),
(191, '2021-09-20', '520020509495', 'SUPARDI', 2, '16000', 'Lunas'),
(192, '2021-09-20', '520020509509', 'MARKAM MARIYAM', 2, '8000', 'Lunas'),
(193, '2021-09-23', '520020509168', 'JUMADI', 2, '26500', 'Lunas'),
(194, '2021-09-23', '083183037136', 'VIOLA', 8, '30000', 'Belum'),
(195, '2021-09-25', '86037218053', 'NUR HUDA', 1, '23000', 'Belum'),
(196, '2021-09-25', '520020509213', 'DARJO/KUMATUN', 2, '25000', 'Lunas'),
(197, '2021-09-27', '082137145353', 'MUHAMMAD NURROIN', 3, '47000', 'Lunas'),
(198, '2021-09-30', '86037218053', 'NUR HUDA', 1, '53000', 'Belum'),
(199, '2021-10-01', '14338468755', 'HARTANTO', 1, '23000', 'Lunas'),
(200, '2021-10-10', '085936107927', 'MBAK SITI XL', 10, '40000', 'Lunas'),
(201, '2021-10-10', '86030038441', 'DIMYATI', 1, '53000', 'Lunas'),
(202, '2021-10-12', '86037218053', 'NUR HUDA', 1, '53000', 'Belum'),
(203, '2021-10-17', '082137145353', 'MUHAMMAD NURROIN', 3, '27000', 'Belum'),
(204, '2021-10-17', '86030038441', 'DIMYATI', 1, '53000', 'Lunas'),
(205, '2021-10-17', '082137145353', 'MUHAMMAD NURROIN', 3, '27000', 'Belum'),
(206, '2021-10-19', '520020786612', 'SYARONI', 2, '52500', 'Lunas'),
(207, '2021-10-20', '520020664080', 'HISYAM AHMAD', 2, '7000', 'Lunas'),
(208, '2021-10-22', '087737627807', 'SALWA', 10, '63000', 'Lunas'),
(209, '2021-10-22', '081325587075', 'MBAK SITI PULSA', 3, '23000', 'Lunas'),
(210, '2021-10-23', '520020509168', 'JUMADI', 2, '24500', 'Lunas'),
(211, '2021-10-31', '86030038441', 'DIMYATI', 1, '23000', 'Lunas'),
(212, '2021-10-31', '86030038441', 'DIMYATI', 1, '23000', 'Lunas'),
(213, '2021-10-31', '32013850485', 'AMINUDDIN', 1, '53000', 'Lunas'),
(214, '2021-11-03', '86030038441', 'DIMYATI', 1, '53000', 'Lunas'),
(215, '2021-11-08', '085936107927', 'MBAK SITI XL', 10, '40000', 'Lunas'),
(216, '2021-11-08', '081325587075', 'MBAK SITI PULSA', 3, '17000', 'Lunas'),
(217, '2021-11-16', '86030038441', 'DIMYATI', 1, '105000', 'Lunas'),
(218, '2021-11-18', '081325587075', 'MBAK SITI PULSA', 3, '23000', 'Lunas'),
(219, '2021-11-21', '520020786612', 'SYARONI', 2, '167000', 'Lunas'),
(220, '2021-11-27', '081325587075', 'MBAK SITI PULSA', 3, '23000', 'Belum');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `tb_jenisbayar`
--
ALTER TABLE `tb_jenisbayar`
  ADD PRIMARY KEY (`id_bayar`);

--
-- Indexes for table `tb_saldo`
--
ALTER TABLE `tb_saldo`
  ADD PRIMARY KEY (`id_saldo`);

--
-- Indexes for table `tb_saldo_akhir`
--
ALTER TABLE `tb_saldo_akhir`
  ADD PRIMARY KEY (`id_saldo_akhr`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `id_bayar` (`id_bayar`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `tb_jenisbayar`
--
ALTER TABLE `tb_jenisbayar`
  MODIFY `id_bayar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tb_saldo`
--
ALTER TABLE `tb_saldo`
  MODIFY `id_saldo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `tb_saldo_akhir`
--
ALTER TABLE `tb_saldo_akhir`
  MODIFY `id_saldo_akhr` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=221;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_bayar`) REFERENCES `tb_jenisbayar` (`id_bayar`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
