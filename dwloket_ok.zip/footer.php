<!-- footer -->
<!-- ============================================================== -->
<footer class="footer text-center text-muted">
    All Rights Reserved by DW LOKET JEPARA @ <?=date('Y'); ?>
</footer>
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->
</div>
</div>
<script src="<?=base_url()?>/files/assets/libs/popper.js/dist/umd/popper.min.js"></script>
<script src="<?=base_url()?>/files/assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?=base_url()?>/files/dist/js/app-style-switcher.js"></script>
<script src="<?=base_url()?>/files/dist/js/feather.min.js"></script>
<script src="<?=base_url()?>/files/assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
<script src="<?=base_url()?>/files/dist/js/sidebarmenu.js"></script>
<!--Custom JavaScript -->
<script src="<?=base_url()?>/files/dist/js/custom.min.js"></script>
<!--This page JavaScript -->
<script src="<?=base_url()?>/files/assets/extra-libs/c3/d3.min.js"></script>
<script src="<?=base_url()?>/files/assets/extra-libs/c3/c3.min.js"></script>
<script src="<?=base_url()?>/files/assets/libs/chartist/dist/chartist.min.js"></script>
<script src="<?=base_url()?>/files/assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
<script src="<?=base_url()?>/files/assets/extra-libs/jvector/jquery-jvectormap-2.0.2.min.js"></script>
<script src="<?=base_url()?>/files/assets/extra-libs/jvector/jquery-jvectormap-world-mill-en.js"></script>
<script src="<?=base_url()?>/files/dist/js/pages/dashboards/dashboard1.min.js"></script>
<script src="<?=base_url()?>/files/assets/extra-libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?=base_url()?>/files/dist/js/pages/datatable/datatable-basic.init.js"></script>
<!-- <script src="<?=base_url()?>/files/dist/js/sweetalert2@11.js"></script> -->
<script src="<?=base_url()?>/files/dist/js/sweetalert2.all.min.js"></script>
</body>

</html>
