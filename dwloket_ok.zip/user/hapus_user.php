<?php
include_once('../config/config.php');
$id = @$_GET['id'];
$sql = $koneksi->query("SELECT * FROM tb_user WHERE id_user ='$id'");
$data = $sql->fetch_assoc();
$koneksi->query("DELETE FROM tb_user WHERE id_user ='$id'");

 ?>

 <script type="text/javascript">
 alert('<?=$data['nama'];?> Berhasil Dihapus')
 window.location.href="<?=base_url('user')?>";
 </script>
