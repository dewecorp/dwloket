<?php
include_once('config/config.php');
setlocale(LC_ALL, 'id-ID', 'id_ID');
date_default_timezone_set('Asia/Jakarta');

$id = @$_GET['id'];
$sql = $koneksi->query("SELECT * FROM transaksi JOIN tb_jenisbayar ON transaksi.id_bayar = tb_jenisbayar.id_bayar WHERE id_transaksi = '$id'");
$data = $sql->fetch_assoc();
$tgl = $data['tgl'];
$harga = $data['harga'];?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Struk Transaksi</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <link rel="icon" type="image/png" sizes="16x16" href="files/assets/images/dwloket_icon.png">
    <link href="files/dist/css/style.min.css" rel="stylesheet">
</head>


<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="float-right">
                            <p><?=date('d/m/Y H:i:s');?></p>
                        </div><br><br>
                        <div class="container">
                            <div>
                                <center>
                                    <h4 style="text-align:center; margin-bottom: 40px;">STRUK TRANSAKSI</h4>
                                </center>
                            </div>
                            <div style="font-size: 18px">
                                <table>
                                    <tr>
                                        <td style="width: 50%;">ID Transaksi</td>
                                        <td style="width: 10%;">:</td>
                                        <td style="width: 80%;"><?=$data['id_transaksi'];?></td>
                                    </tr>
                                    <tr>
                                        <td style="width: 30%;">Tanggal Transaksi</td>
                                        <td style="width: 10%;">:</td>
                                        <td style="width: 65%;"><?=date('d/m/Y', strtotime($tgl));?></td>
                                    </tr>
                                    <tr>
                                        <td style="width: 30%;">ID Pelanggan</td>
                                        <td style="width: 10%;">:</td>
                                        <td style="width: 65%;"><?=$data['idpel'];?></td>
                                    </tr>
                                    <tr>
                                        <td style="width: 30%; vertical-align: top;">Nama Pelanggan</td>
                                        <td style="width: 10%;">:</td>
                                        <td style="width: 65%;"><?=$data['nama'];?></td>
                                    </tr>
                                    <tr>
                                        <td style="width: 30%; vertical-align: top;">Jenis Pembayaran</td>
                                        <td style="width: 10%;">:</td>
                                        <td style="width: 65%;"><?=$data['jenis_bayar'];?></td>
                                    </tr>
                                    <tr>
                                        <td style="width: 30%;">Harga</td>
                                        <td style="width: 10%;">:</td>
                                        <td style="width: 65%;">Rp. <?=number_format($data['harga'], 0, ",", ".");?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 30%;">Keterangan</td>
                                        <td style="width: 10%;">:</td>
                                        <td style="width: 65%;"><?=$data['ket'];?>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            <div><br>
                                <center>
                                    <h5 style="text-align:center">Terbilang:
                                        <i><?=terbilang($harga);?> Rupiah</i>
                                    </h5>
                                </center>
                            </div>
                            <center>
                                <p style="font-size: 18px">Struk ini sebagai bukti transaksi di DW LOKET.
                                    Informasi hubungi 082331838221.</p>
                            </center>
                            <div>
                                <center>
                                    <h5 style="text-align:center">Terima Kasih Atas Kepercayaan Anda</h5>
                                </center>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
<script>
window.print();
</script>