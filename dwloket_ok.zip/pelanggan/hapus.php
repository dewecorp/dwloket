<?php
include_once('../config/config.php');
$id = @$_GET['id'];
$sql = $koneksi->query("SELECT * FROM pelanggan WHERE id_pelanggan='$id'");
$data = $sql->fetch_assoc();
$koneksi->query("DELETE FROM pelanggan WHERE id_pelanggan='$id'");

 ?>

<script type="text/javascript">
alert('Pelanggan Bernama <?=$data['nama'];?> Berhasil Dihapus')
window.location.href = "<?=base_url('pelanggan')?>";
</script>