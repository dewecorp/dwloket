<?php
include_once('../header.php');
include_once('../config/config.php');
$id = @$_GET['id'];
$data_pelanggan = $koneksi->query("SELECT * FROM pelanggan");
$jumlah_pelanggan = $data_pelanggan->num_rows;
$data_transaksi = $koneksi->query("SELECT * FROM transaksi");
$jumlah_transaksi = $data_transaksi->num_rows;
$data_jenisbayar = $koneksi->query("SELECT * FROM tb_jenisbayar");
$jumlah_jenisbayar = $data_jenisbayar->num_rows;
$sql = $koneksi->query("SELECT * FROM tb_saldo WHERE id_saldo ORDER BY tgl DESC");
$data = $sql->fetch_assoc();
// $saldo = $koneksi->query("SELECT * FROM tb_total_saldo WHERE id_total_saldo ORDER BY id desc ");
// $tampil = $saldo->fetch_assoc();
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- Tell the browser to be responsive to screen width -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- Favicon icon -->
        <link rel="icon" type="image/png" sizes="16x16" href="<?=base_url()?>/files/assets/images/dwloket_icon.png">
        <title>Dashboard</title>
        <!-- Custom CSS -->
        <link href="<?=base_url()?>/files/assets/extra-libs/c3/c3.min.css" rel="stylesheet">
        <link href="<?=base_url()?>/files/assets/libs/chartist/dist/chartist.min.css" rel="stylesheet">
        <link href="<?=base_url()?>/files/assets/extra-libs/jvector/jquery-jvectormap-2.0.2.css" rel="stylesheet" />
        <!-- Custom CSS -->
        <link href="<?=base_url()?>/files/dist/css/style.min.css" rel="stylesheet">
    </head>
    <body>
        <div class="container-fluid">
            <div class="card-group">
                <div class="card border-right">
                    <div class="card-body">
                        <div class="d-flex d-lg-flex d-md-block align-items-center">
                            <div>
                                <div class="d-inline-flex align-items-center">
                                    <h2 class="text-dark mb-1 font-weight-medium"><?=$jumlah_pelanggan?></h2>
                                </div>
                                <h4 class="text-muted font-weight-normal mb-0 w-100 text-truncate">Pelanggan</h4><br>
                                <a href="<?=base_url('pelanggan')?>" class="btn btn-primary btn-rounded btn-sm">Lihat <i
                                data-feather="arrow-right-circle" class="feather-icon"></i></a>
                            </div>
                            <div class="ml-auto mt-md-3 mt-lg-0">
                                <span class="opacity-7 text-muted"><i data-feather="users"></i></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card border-right">
                    <div class="card-body">
                        <div class="d-flex d-lg-flex d-md-block align-items-center">
                            <div>
                                <h2 class="text-dark mb-1 w-100 text-truncate font-weight-medium"><?=$jumlah_jenisbayar?>
                                </h2>
                                <h4 class="text-muted font-weight-normal mb-0 w-100 text-truncate">Jenis Pembayaran
                                </h4><br>
                                <a href="<?=base_url('jenisbayar')?>" class="btn btn-success btn-sm btn-rounded">Lihat <i
                                data-feather="arrow-right-circle" class="feather-icon"></i></a>
                            </div>
                            <div class="ml-auto mt-md-3 mt-lg-0">
                                <span class="opacity-7 text-muted"><i data-feather="dollar-sign"></i></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card border-right">
                    <div class="card-body">
                        <div class="d-flex d-lg-flex d-md-block align-items-center">
                            <div>
                                <div class="d-inline-flex align-items-center">
                                    <h2 class="text-dark mb-1 font-weight-medium"><?=$jumlah_transaksi?></h2>
                                </div>
                                <h4 class="text-muted font-weight-normal mb-0 w-100 text-truncate">Transaksi</h4><br>
                                <a href="<?=base_url('transaksi')?>" class="btn btn-warning btn-sm btn-rounded">Lihat <i
                                data-feather="arrow-right-circle" class="feather-icon"></i></a>
                            </div>
                            <div class="ml-auto mt-md-3 mt-lg-0">
                                <span class="opacity-7 text-muted"><i data-feather="shopping-cart"></i></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card border-right">
                    <div class="card-body">
                        <div class="d-flex d-lg-flex d-md-block align-items-center">
                            <div>
                                <div class="d-inline-flex align-items-center">
                                    <h2 class="text-dark mb-1 font-weight-medium">Rp. <?=number_format($data['saldo'], 0, ",", ".");?></h2>
                                </div>
                                <h4 class="text-muted font-weight-normal mb-0 w-100 text-truncate">Saldo Akhir</h4><br>
                                <a href="<?=base_url('saldo/total_saldo.php')?>" class="btn btn-danger btn-sm btn-rounded">Lihat <i
                                data-feather="arrow-right-circle" class="feather-icon"></i></a>
                            </div>
                            <div class="ml-auto mt-md-3 mt-lg-0">
                                <span class="opacity-7 text-muted"><i data-feather="credit-card"></i></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="text-center">
                                <div class="logo-icon">
                                  <!--   <img src="<?=base_url()?>/files/assets/images/dwloket_logo.png" alt="logo" width="250px" height="70px"> -->
                                </div>
                                <h1 class="display-4"><b>DW LOKET JEPARA</b></h1>
                                <p class="lead"><b>Loket Resmi Pembayaran PLN, Token PLN Pra Bayar, Pulsa Pra Bayar, Pulsa Pasca Bayar, Kuota Data, BPJS Kesehatan, PDAM, E-Money, Multifinance, Voucher Game, Dan Lain-lain.</b></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        include_once('../footer.php');
        ?>
    </body>
</html>