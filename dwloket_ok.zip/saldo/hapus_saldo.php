<?php
include_once('../config/config.php');
$id = @$_GET['id'];

$koneksi->query("DELETE FROM tb_saldo WHERE id_saldo ='$id'");

 ?>

 <script type="text/javascript">
 alert('Saldo Berhasil Dihapus')
 window.location.href="<?=base_url('saldo')?>";
 </script>
