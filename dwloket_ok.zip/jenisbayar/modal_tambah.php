<div id="modaltambah" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">INPUT JENIS BAYAR</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <form action="" method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="jenis">Jenis Pembayaran</label>
                        <input type="text" name="jenis" class="form-control" placeholder="Jenis Pembayaran" autofocus
                        required>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="submit" name="simpan" class="btn btn-success btn-sm btn-rounded" value="Simpan">
                    <button type="button" class="btn btn-danger btn-sm btn-rounded" data-dismiss="modal">Tutup</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
if(@$_POST['simpan']) {
$jenis = @$_POST['jenis'];
$sql = $koneksi->query("INSERT INTO tb_jenisbayar (jenis_bayar) VALUES ('$jenis')");
if ($sql) {
?>
<script>
Swal.fire({
position: 'top-center',
icon: 'success',
title: '<?=$jenis;?>',
text: 'Berhasil Ditambahkan',
showConfirmButton: true,
timer: 3000
}, 10);
window.setTimeout(function () {
document.location.href = '<?=base_url('
jenisbayar ')?>';
}, 1500);
</script>
<?php
}
}
?>