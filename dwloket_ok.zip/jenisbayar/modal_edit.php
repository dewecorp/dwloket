<?php
$sql = $koneksi->query("SELECT * FROM tb_jenisbayar");
while($data = $sql->fetch_assoc()){
?>
<div id="modaledit<?=$data['id_bayar'];?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">EDIT JENIS BAYAR</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <form action="" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="id" value="<?=$data['id_bayar'];?>">
                    <div class="form-group">
                        <label for="nama">Jenis Pembayaran</label>
                        <input type="text" name="jenis" class="form-control" value="<?=$data['jenis_bayar'];?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="submit" name="edit" class="btn btn-success btn-sm btn-rounded" value="Simpan">
                    <button type="button" class="btn btn-danger btn-sm btn-rounded" data-dismiss="modal">Tutup</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
if(@$_POST['edit']) {
$id    = @$_POST['id'];
$jenis = @$_POST['jenis'];
$koneksi->query("UPDATE tb_jenisbayar SET jenis_bayar='$jenis' WHERE id_bayar='$id'");
?>
<script>
Swal.fire({
position: 'top-center',
icon: 'success',
title: '<?=$jenis;?>',
text: 'Berhasil Diedit',
showConfirmButton: true,
timer: 3000
}, 10);
window.setTimeout(function () {
document.location.href = '<?=base_url('
jenisbayar ')?>';
}, 1500);
</script>
<?php
}
}
?>