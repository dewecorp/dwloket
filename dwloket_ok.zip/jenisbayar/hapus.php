<?php
include_once('../config/config.php');
$id = @$_GET['id'];
$sql = $koneksi->query("SELECT * FROM jenis_bayar WHERE id_bayar ='$id'");
$data = $sql->fetch_assoc();
$jenis_bayar = $data['jenis_bayar'];
$koneksi->query("DELETE FROM jenis_bayar WHERE id_bayar ='$id'");

 ?>

 <script type="text/javascript">
 alert('<?=$jenis_bayar?> Berhasil Dihapus')
 window.location.href="<?=base_url('jenisbayar')?>";
 </script>
