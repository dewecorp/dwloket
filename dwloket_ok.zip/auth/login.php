<?php
ob_start();
include "../config/config.php";

if (@$_SESSION['admin'] || @$_SESSION['user']) {
	echo "<script>window.location='".base_url()."';</script>";
} else {
?>


<!DOCTYPE html>
<html dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?=base_url()?>/files/assets/images/dwloket_icon.png">
    <title>Login DW LOKET</title>
    <!-- Custom CSS -->
    <link href="<?=base_url()?>/files/dist/css/style.min.css" rel="stylesheet">

</head>

<body>
    <div class="main-wrapper">
        <!-- ============================================================== -->
        <!-- Preloader - style you can find in spinners.css -->
        <!-- ============================================================== -->
        <div class="preloader">
            <div class="lds-ripple">
                <div class="lds-pos"></div>
                <div class="lds-pos"></div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- Preloader - style you can find in spinners.css -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Login box.scss -->
        <!-- ============================================================== -->
        <div class="auth-wrapper d-flex no-block justify-content-center align-items-center position-relative"
            style="background:url(<?=base_url()?>/files/assets/images/big/auth-bg.jpg) no-repeat center center;">
            <div class="auth-box row">
                <div class="col-lg-7 col-md-5 modal-bg-img"
                    style="background-image: url(<?=base_url()?>/files/assets/images/big/3.jpg);">
                </div>
                <div class="col-lg-5 col-md-7 bg-white">
                    <div class="p-3">
                        <div class="text-center">
                            <img src="<?=base_url()?>/files/assets/images/dwloket_icon.png" alt="wrapkit">
                        </div>
                        <h2 class="mt-3 text-center">DW LOKET JEPARA</h2>
                        <p class="text-center">Masukkan Username dan Password Anda</p>
                        <form class="mt-4" method="POST">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label class="text-dark" for="uname">Username</label>
                                        <input class="form-control" name="user" type="text" placeholder="Username">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label class="text-dark" for="pwd">Password</label>
                                        <input class="form-control" name="pass" type="password" placeholder="Password">
                                    </div>
                                </div>
                                <div class="col-lg-12 text-center">
                                    <input type="submit" name="login" value="Masuk"
                                        class="btn btn-block btn-success btn-rounded">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- Login box.scss -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- All Required js -->
    <!-- ============================================================== -->
    <script src="<?=base_url()?>/files/assets/libs/jquery/dist/jquery.min.js "></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?=base_url()?>/files/assets/libs/popper.js/dist/umd/popper.min.js "></script>
    <script src="<?=base_url()?>/files/assets/libs/bootstrap/dist/js/bootstrap.min.js "></script>
    <!-- ============================================================== -->
    <!-- This page plugin js -->
    <!-- ============================================================== -->
    <script>
        $(".preloader ").fadeOut();
    </script>
</body>

</html>
<?php
if (isset($_POST['login'])) {
	$username = $_POST['user'];
	$pass = $_POST['pass'];
    
	$sql = $koneksi->query("SELECT * FROM tb_user WHERE username='$username' AND password='$pass'");
	$data = $sql->fetch_assoc();
	$login = $sql->num_rows;
	if ($login >=1) {
		session_start();

			$_SESSION['level'] = $data['level'];
			$_SESSION['id_user'] = $data['id_user'];
			 echo "<script>window.location='".base_url('home')."';</script>";
            ?>

<script type="text/javascript">
    alert("Selamat Login Berhasil");
</script>

            <?php

		} else {
?>
<script type="text/javascript">
    alert("Login Gagal, Username / Password Salah!");
</script>
<?php
}
}
}
?>